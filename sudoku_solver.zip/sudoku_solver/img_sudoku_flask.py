
import dash
from dash.dependencies import Input, Output
import dash_core_components as dcc
import dash_bootstrap_components as dbc
import dash_html_components as html
from sudoku_flask import *
import cv2
import base64
import pandas as pd
import numpy as np

app = dash.Dash(external_stylesheets=[dbc.themes.BOOTSTRAP])

app.layout = html.Div([
    html.Div(dbc.Row(dbc.Col(dbc.Card(html.Img(src='assets/sudoku_ai.gif', style={'margin': 'auto'}),
                    style={'margin': 'auto'}, className='table_bgn'), style={'margin': 'auto'},
                             className='table_bgn'), className='table_bgn'), className='table_bgn'),
    dcc.Upload(
        id='upload-image',
        children=html.Div([
            'Drag and Drop or ',
            html.A('Take photo', className='photo')
        ]),
        style={
            'width': '100%',
            'height': '60px',
            'lineHeight': '60px',
            'borderWidth': '1px',
            'borderStyle': 'dashed',
            'borderRadius': '5px',
            'textAlign': 'center',
            'margin': '10px'
        },
        # Allow multiple files to be uploaded
        multiple=True
    ),
    html.Div(dbc.Row(dbc.Col(id='table', className='table_bgn'), className='table_bgn'), className='table_bgn')
])


@app.callback(Output('table', 'children'),
              [Input('upload-image', 'contents')])
def update_output(c):
    if c is not None:
        encoded_data = c[0].split(',')[1]
        nparr = np.fromstring(base64.b64decode(encoded_data), np.uint8)
        img = cv2.imdecode(nparr, cv2.IMREAD_GRAYSCALE)
        solution = main_function(img)
        if len(solution)==9:
            df = pd.DataFrame(solution)
            card = dbc.Card([dbc.Table.from_dataframe(df, dark=True, bordered=True,
                                           hover=True, responsive=True, size='sm',
                                           className='container', style={'margin': 'auto'})],
                                           className='table_bgn')
        elif len(solution)==0:
            card = dbc.Card([html.A('AI cannot read the sudoku, please try another pic...', style={'margin': 'auto'})],
                            className='table_bgn')
        elif len(solution)==2:
            card = dbc.Card(
                [html.A('AI cannot find a sudoku in the pic, make sure it is a sudoku pic...', style={'margin': 'auto'})],
                className='table_bgn')
        print()
        return card

if __name__ == '__main__':
    app.run_server(debug=True)